// Configurações do jogo
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = 800;
canvas.height = 600;
let gameOver = false;
let time = 0;

// Carrega a imagem do carro
const carImage = new Image();
carImage.src = 'carro.png';

// Cria o carro do jogador
const playerCar = {
  x: canvas.width / 2 - 40, // Ajuste na posição inicial do carro
  y: canvas.height - 100, // Ajuste na posição inicial do carro
  width: 80, // Largura do carro
  height: 60, // Altura do carro
  speed: 7,
  maxSpeed: 15,
  acceleration: 0.02,
  draw: function() {
    ctx.drawImage(carImage, this.x, this.y, this.width, this.height);
  }
};

// Lista de obstáculos
let obstacles = [];

// Classe para obstáculos
class Obstacle {
  constructor(x, y, width, height, speed) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.speed = speed;
  }

  draw() {
    ctx.fillStyle = 'red';
    ctx.fillRect(this.x, this.y, this.width, this.height);
  }

  move() {
    this.y += this.speed;
  }
}

// Função para criar obstáculos
function createObstacle() {
  const obstacleWidth = 80; // Largura igual à do carro
  const obstacleHeight = 60; // Altura igual à do carro
  const x = Math.random() * (canvas.width - obstacleWidth);
  const y = -obstacleHeight;
  const speed = Math.random() * 2 + 2;
  const newObstacle = new Obstacle(x, y, obstacleWidth, obstacleHeight, speed);
  obstacles.push(newObstacle);
}

// Desenha a pista
function drawRoad() {
  // Desenha a pista
  ctx.fillStyle = 'gray';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Desenha as listras na pista
  ctx.fillStyle = 'yellow';
  const stripeWidth = 10;
  const stripeHeight = 100;
  const numStripes = Math.floor(canvas.height / (2 * stripeHeight));
  const spaceBetweenStripes = (canvas.height - numStripes * stripeHeight) / (numStripes - 1);

  for (let i = 0; i < numStripes; i++) {
    const x = canvas.width / 2 - stripeWidth / 2;
    const y = i * (stripeHeight + spaceBetweenStripes);

    ctx.fillRect(x, y, stripeWidth, stripeHeight);
  }
}

// Exibe o tempo na tela
function drawTime() {
  ctx.fillStyle = 'black';
  ctx.font = '24px Arial';
  ctx.fillText('Tempo: ' + time, 20, 30);
}

// Loop do jogo
let gameSpeed = 1;
function gameLoop() {
  if (!gameOver) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawRoad();
    playerCar.draw();
    drawTime();

    time++;

    gameSpeed += 0.001;

    if (playerCar.speed < playerCar.maxSpeed) {
      playerCar.speed += playerCar.acceleration;
    }

    obstacles.forEach((obstacle, index) => {
      obstacle.draw();
      obstacle.move();

      if (checkCollision(playerCar, obstacle)) {
        gameOver = true;
        endGame();
      }

      if (obstacle.y > canvas.height) {
        obstacles.splice(index, 1);
      }
    });

    if (Math.random() < 0.01) {
      createObstacle();
    }

    requestAnimationFrame(gameLoop);
  }
}

// Função para verificar colisão entre dois objetos retangulares
function checkCollision(rect1, rect2) {
  return rect1.x < rect2.x + rect2.width &&
         rect1.x + rect1.width > rect2.x &&
         rect1.y < rect2.y + rect2.height &&
         rect1.y + rect1.height > rect2.y;
}

// Função para encerrar o jogo
function endGame() {
  alert('Game Over! Tempo: ' + time);
}

// Event listener para teclas de seta
document.addEventListener('keydown', function(event) {
  if (!gameOver) {
    if (event.key === 'ArrowLeft' && playerCar.x > 0) {
      playerCar.x -= playerCar.speed;
    } else if (event.key === 'ArrowRight' && playerCar.x < canvas.width - playerCar.width) {
      playerCar.x += playerCar.speed;
    }
  }
});

// Inicializa o jogo
gameLoop();

